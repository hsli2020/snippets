################################################################################
#                         receivemail.class.php  Version: 1.0                   #
#                                                                              #
#                                                                              #
#                          Created by Mitul Koradia                            #
#                                                                              #
#                        Email: mitulkoradia@gmail.com                         #
#                             Cell No +919825273322                           #
################################################################################

This is simple but use full class for the Application Developer

Application :
This class can be used to retrieve mail from pop3/imap mailbox. The class can be used to generate auto response, ticket/post reply via mail etc. The class is able to get the attachment from the mail too. 

--------------------------------------------------------------------------------
System Requirement :

Internet connection 
php with imap library

	
